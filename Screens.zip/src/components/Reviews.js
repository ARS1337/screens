import React from "react";
import "../App.css";

function Reviews() {
  return (
    <>
    <div class="review-container col-10">
      <div class="reviews-header col-12">
        <h2 class="row col-12">Reviews</h2>

        {/* <p class="col-2">4*</p> */}
        {/* 888888888888888888 */}
        <p class="row col-2">Rate your Experience</p>
        <p class="rating col-3">
      <input type="radio" name="rating" id="rating-5"/>
      <label for="rating-5"></label>
      <input type="radio" name="rating" id="rating-4"/>
      <label for="rating-4"></label>
      <input type="radio" name="rating" id="rating-3"/>
      <label for="rating-3"></label>
      <input type="radio" name="rating" id="rating-2"/>
      <label for="rating-2"></label>
      <input type="radio" name="rating" id="rating-1"/>
      <label for="rating-1"></label>
      </p>
         {/* 8888888888888888888888888888         */}
        <div class="review-input row col-12">
          <p class="col-2 ">Write a Review</p>
          <textarea class="col-6" rows="5"></textarea>
          <button type="submit" class="col-2 submit-review">
            SUBMIT
          </button>
        </div>

        <p class="col-12 row customer-review-header">Customer Reviews</p>

        {/* <!-- replace 4* with images afterwards --> */}
        <img src="./redStar.png" class="row col-2"/>
        <h3 class="col-2">205 Reviews</h3>

        <hr class="row review-line col-12 "></hr>
          <br />
          {/* <!-- user review start  -->
                    <!-- replace profile-pic with images afterwards --> */}

          <div class="user-review-container">
            <div class="user row col-12">
            <img src="../images jpg/Reviews/Profile.png" class="col-1 profile-pic" />
            <h4 class="col-8 user-name">Rupali Singh</h4>
            <h3 class="col-4 review-date">30th August 2020</h3>
            </div>


            <div class="user-rating row col-12">
            <img src="../images jpg/Reviews/redRect.svg" class="row col-1"/>
            <p class="tdlr col-11">Disappointed</p>
            </div>

            <div class="space row col-1"></div>
            <p class="col-11 user-review">
              Lorem ipsum, dolor sit amet consectetur adipisicing elit. Rem
              quisquam iste error ab ut sunt officiis, nobis delectus.
              Accusamus, maxime. Libero, minima! Placeat, veniam nulla dolores
              nemo dignissimos adipisci explicabo?
            </p>
            <hr class="row review-line col-12 " ></hr>
          </div>

          {/* <!-- user review end  --> */}
        </div>
        </div>
    </>
  );
}

export default Reviews;
