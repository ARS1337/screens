import React from "react";
// import styles from "../screen4.css";
import '../App.css';

function Videos() {
  return (
    <div class="videos">
      <h2 class="row col-12 videos-header">Videos</h2>
      <div class="card">
        <img src="images jpg/videoPic1.jpg" alt="" srcset="" />
        <div class="video-title">
          <h2>Paneer Butter Masala</h2>
        </div>
        <div class="desc">
          how to make a dhaba style paneer butter masala in 30 min{" "}
        </div>
        <div class="uploadDate">
          <h5>Uplaoded on : 24 Aug 2020</h5>
        </div>
      </div>
      <div class="card">
        <img src="images jpg/videoPic1.jpg" alt="" srcset="" />
        <div class="video-title">
          <h2>Paneer Butter Masala</h2>
        </div>
        <div class="desc">
          how to make a dhaba style paneer butter masala in 30 min{" "}
        </div>
        <div class="uploadDate">
          <h5>Uplaoded on : 24 Aug 2020</h5>
        </div>
      </div><div class="card">
        <img src="images jpg/videoPic1.jpg" alt="" srcset="" />
        <div class="video-title">
          <h2>Paneer Butter Masala</h2>
        </div>
        <div class="desc">
          how to make a dhaba style paneer butter masala in 30 min{" "}
        </div>
        <div class="uploadDate">
          <h5>Uplaoded on : 24 Aug 2020</h5>
        </div>
      </div><div class="card">
        <img src="images jpg/videoPic1.jpg" alt="" srcset="" />
        <div class="video-title">
          <h2>Paneer Butter Masala</h2>
        </div>
        <div class="desc">
          how to make a dhaba style paneer butter masala in 30 min{" "}
        </div>
        <div class="uploadDate">
          <h5>Uplaoded on : 24 Aug 2020</h5>
        </div>
      </div>
    </div>
  );
}

export default Videos;
