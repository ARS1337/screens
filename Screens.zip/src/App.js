import logo from './logo.svg';
import './App.css';
import Videos from './components/Videos';
import Title from './components/Title';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Playground from './components/Playground';
// import './screen4.css';
import Reviews from './components/Reviews';
import Recommended from './components/Recommended';

function App() {
  return (
    <div className="App">
       <div class="main">
         <Header/>
         {/* <Videos/> */}
         {/* <Reviews/> */}
         {/* <Recommended/> */}
         {/* <Navigation/> */}
         {/* <Title/> */}
      </div>
    </div>
  );
}

export default App;
